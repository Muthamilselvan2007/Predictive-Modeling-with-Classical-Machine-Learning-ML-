"""
Iris Species Predictor — Streamlit App
----------------------------------------
A small web app built on top of the Logistic Regression model developed
in iris_classification.ipynb. Lets a user enter flower measurements and
get a live species prediction, plus shows the model's test-set metrics.

Run locally with:
    pip install streamlit scikit-learn pandas matplotlib
    streamlit run app.py
"""

import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, ConfusionMatrixDisplay
)

st.set_page_config(page_title="Iris Species Predictor", page_icon="🌸", layout="centered")


@st.cache_resource
def load_model():
    """Load data and train the model once; cached across reruns/users."""
    iris = load_iris(as_frame=True)
    df = iris.frame.copy()
    X = df[iris.feature_names]
    y = df["target"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.30, random_state=42, stratify=y
    )

    model = LogisticRegression(max_iter=200)
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)

    metrics = {
        "accuracy": accuracy_score(y_test, y_pred),
        "precision": precision_score(y_test, y_pred, average="macro"),
        "recall": recall_score(y_test, y_pred, average="macro"),
        "f1": f1_score(y_test, y_pred, average="macro"),
    }
    cm = confusion_matrix(y_test, y_pred)

    return model, iris, metrics, cm


model, iris, metrics, cm = load_model()

st.title("🌸 Iris Species Predictor")
st.write(
    "This app uses a **Logistic Regression** model trained on the classic "
    "Iris dataset to predict a flower's species from its measurements."
)

# ---- Sidebar: model performance ----
with st.sidebar:
    st.header("Model Performance")
    st.metric("Accuracy", f"{metrics['accuracy']:.2%}")
    st.metric("Precision (macro)", f"{metrics['precision']:.2%}")
    st.metric("Recall (macro)", f"{metrics['recall']:.2%}")
    st.metric("F1-Score (macro)", f"{metrics['f1']:.2%}")

    st.subheader("Confusion Matrix")
    fig, ax = plt.subplots(figsize=(3, 3))
    ConfusionMatrixDisplay(cm, display_labels=iris.target_names).plot(
        ax=ax, cmap="Blues", colorbar=False
    )
    st.pyplot(fig)

# ---- Main: prediction form ----
st.header("Try a Prediction")
st.write("Adjust the sliders to describe a flower, then see the predicted species.")

col1, col2 = st.columns(2)
with col1:
    sepal_length = st.slider("Sepal Length (cm)", 4.0, 8.0, 5.8, 0.1)
    sepal_width = st.slider("Sepal Width (cm)", 2.0, 4.5, 3.0, 0.1)
with col2:
    petal_length = st.slider("Petal Length (cm)", 1.0, 7.0, 4.3, 0.1)
    petal_width = st.slider("Petal Width (cm)", 0.1, 2.5, 1.3, 0.1)

input_df = pd.DataFrame(
    [[sepal_length, sepal_width, petal_length, petal_width]],
    columns=iris.feature_names,
)

if st.button("Predict Species", type="primary"):
    pred_class = model.predict(input_df)[0]
    pred_proba = model.predict_proba(input_df)[0]
    species_name = iris.target_names[pred_class]

    st.success(f"Predicted species: **{species_name}**")

    proba_df = pd.DataFrame(
        {"Species": iris.target_names, "Probability": pred_proba}
    ).sort_values("Probability", ascending=False)
    st.bar_chart(proba_df.set_index("Species"))

st.caption(
    "Dataset: scikit-learn's built-in Iris dataset (150 samples, 3 classes). "
    "Model trained on a 70/30 train-test split."
)
