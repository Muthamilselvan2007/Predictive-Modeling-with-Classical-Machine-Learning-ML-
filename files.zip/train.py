"""
Fine-Tuning a Large Language Model (DistilBERT) for Text Classification
=========================================================================
Project: Transfer Learning + NLP — Sentiment Analysis on the IMDb Movie
Review Dataset.

This script:
  1. Loads the IMDb dataset (25,000 train / 25,000 test reviews).
  2. Loads a pre-trained "distilbert-base-uncased" checkpoint.
  3. Tokenizes the text data.
  4. Fine-tunes the model for binary sentiment classification
     (positive / negative) using the Hugging Face Trainer API.
  5. Evaluates the model (accuracy, F1-score).
  6. Saves the fine-tuned model + tokenizer to disk.
  7. Runs inference on a few new, unseen sentences.

Run:
    python train.py

Recommended environment: Google Colab (free GPU) or a machine with a
CUDA-capable GPU. Training on CPU works but is much slower.
"""

import numpy as np
import evaluate
from datasets import load_dataset
from transformers import (
    AutoTokenizer,
    AutoModelForSequenceClassification,
    DataCollatorWithPadding,
    TrainingArguments,
    Trainer,
)

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
MODEL_CHECKPOINT = "distilbert-base-uncased"
OUTPUT_DIR = "./sentiment-distilbert-imdb"
NUM_EPOCHS = 3
BATCH_SIZE = 16
LEARNING_RATE = 2e-5

# Set to None to train on the FULL 25k/25k dataset (slow on CPU).
# Set to a small integer (e.g. 2000) for a quick end-to-end test run.
TRAIN_SUBSET_SIZE = 2000
EVAL_SUBSET_SIZE = 1000


def main():
    # -----------------------------------------------------------------
    # Step 1: Data Acquisition — load the public IMDb dataset
    # -----------------------------------------------------------------
    print("Loading IMDb dataset...")
    # Note: the old bare "imdb" repo on the Hub was retired; the dataset
    # now lives at "stanfordnlp/imdb".
    raw_datasets = load_dataset("stanfordnlp/imdb")

    if TRAIN_SUBSET_SIZE:
        raw_datasets["train"] = raw_datasets["train"].shuffle(seed=42).select(
            range(TRAIN_SUBSET_SIZE)
        )
    if EVAL_SUBSET_SIZE:
        raw_datasets["test"] = raw_datasets["test"].shuffle(seed=42).select(
            range(EVAL_SUBSET_SIZE)
        )

    print(raw_datasets)

    # -----------------------------------------------------------------
    # Step 2: Model & Tokenizer Loading
    # -----------------------------------------------------------------
    print(f"Loading tokenizer and model from '{MODEL_CHECKPOINT}'...")
    tokenizer = AutoTokenizer.from_pretrained(MODEL_CHECKPOINT)
    model = AutoModelForSequenceClassification.from_pretrained(
        MODEL_CHECKPOINT, num_labels=2
    )

    # -----------------------------------------------------------------
    # Step 3: Data Preprocessing (Tokenization)
    # -----------------------------------------------------------------
    def tokenize_function(examples):
        return tokenizer(examples["text"], truncation=True, max_length=256)

    print("Tokenizing dataset...")
    tokenized_datasets = raw_datasets.map(tokenize_function, batched=True)
    tokenized_datasets = tokenized_datasets.remove_columns(["text"])
    tokenized_datasets = tokenized_datasets.rename_column("label", "labels")
    tokenized_datasets.set_format("torch")

    data_collator = DataCollatorWithPadding(tokenizer=tokenizer)

    # -----------------------------------------------------------------
    # Step 4: Metrics — accuracy + F1
    # -----------------------------------------------------------------
    accuracy_metric = evaluate.load("accuracy")
    f1_metric = evaluate.load("f1")

    def compute_metrics(eval_pred):
        logits, labels = eval_pred
        predictions = np.argmax(logits, axis=-1)
        acc = accuracy_metric.compute(predictions=predictions, references=labels)
        f1 = f1_metric.compute(predictions=predictions, references=labels)
        return {"accuracy": acc["accuracy"], "f1": f1["f1"]}

    # -----------------------------------------------------------------
    # Step 5: Fine-Tuning with the Hugging Face Trainer API
    #
    # Key concept — Transfer Learning:
    # DistilBERT was pre-trained on a massive, general-purpose text
    # corpus (a distilled version of BERT, trained via language
    # modeling on BookCorpus + English Wikipedia). That pre-training
    # taught the model general-purpose language understanding: grammar,
    # word meaning, and context. Instead of training a text-classification
    # model from scratch, we re-use those learned weights and only
    # adapt ("fine-tune") them — with a small classification head added
    # on top — to our specific downstream task (movie review sentiment).
    # This lets a small labeled dataset reach strong accuracy in a
    # fraction of the time/compute a from-scratch model would need.
    # -----------------------------------------------------------------
    training_args = TrainingArguments(
        output_dir=OUTPUT_DIR,
        eval_strategy="epoch",
        save_strategy="epoch",
        learning_rate=LEARNING_RATE,
        per_device_train_batch_size=BATCH_SIZE,
        per_device_eval_batch_size=BATCH_SIZE,
        num_train_epochs=NUM_EPOCHS,
        weight_decay=0.01,
        load_best_model_at_end=True,
        metric_for_best_model="f1",
        logging_steps=50,
        report_to="none",
    )

    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=tokenized_datasets["train"],
        eval_dataset=tokenized_datasets["test"],
        processing_class=tokenizer,
        data_collator=data_collator,
        compute_metrics=compute_metrics,
    )

    print("Starting fine-tuning...")
    trainer.train()

    # -----------------------------------------------------------------
    # Step 6: Evaluation
    # -----------------------------------------------------------------
    print("Evaluating on the test set...")
    eval_results = trainer.evaluate()
    print("Final evaluation results:", eval_results)

    # -----------------------------------------------------------------
    # Step 7: Save the fine-tuned model + tokenizer
    # -----------------------------------------------------------------
    print(f"Saving model to '{OUTPUT_DIR}/final_model'...")
    trainer.save_model(f"{OUTPUT_DIR}/final_model")
    tokenizer.save_pretrained(f"{OUTPUT_DIR}/final_model")

    # -----------------------------------------------------------------
    # Step 8: Inference on new, unseen sentences
    # -----------------------------------------------------------------
    sample_sentences = [
        "This movie was an absolute masterpiece, I loved every minute of it!",
        "What a waste of time. The plot made no sense and the acting was terrible.",
        "It was okay, not great, but not the worst thing I've watched either.",
    ]

    print("\nRunning inference on sample sentences:")
    predict_sentiment(sample_sentences, model, tokenizer)


def predict_sentiment(sentences, model, tokenizer):
    """Predict sentiment (POSITIVE/NEGATIVE) for a list of raw sentences."""
    import torch

    model.eval()
    inputs = tokenizer(
        sentences, padding=True, truncation=True, max_length=256, return_tensors="pt"
    )
    with torch.no_grad():
        outputs = model(**inputs)
    probs = torch.nn.functional.softmax(outputs.logits, dim=-1)
    preds = torch.argmax(probs, dim=-1)

    id2label = {0: "NEGATIVE", 1: "POSITIVE"}
    for sentence, pred, prob in zip(sentences, preds, probs):
        label = id2label[pred.item()]
        confidence = prob[pred].item()
        print(f"  [{label}] ({confidence:.2%} confidence)  {sentence}")


if __name__ == "__main__":
    main()
