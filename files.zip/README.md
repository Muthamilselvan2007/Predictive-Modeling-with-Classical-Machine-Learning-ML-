# Fine-Tuning DistilBERT for Sentiment Classification (IMDb)

**Core focus:** Large Language Models (LLM), Transfer Learning, NLP
**Base model:** `distilbert-base-uncased`
**Dataset:** IMDb Movie Review Dataset (25k train / 25k test, binary sentiment)
**Deliverable:** `Fine_Tuning_DistilBERT_Sentiment.ipynb` (Jupyter Notebook), plus
equivalent standalone scripts `train.py` and `inference.py`.

---

## What's in this project

| File | Purpose |
|---|---|
| `Fine_Tuning_DistilBERT_Sentiment.ipynb` | The main deliverable — run top to bottom in Jupyter/Colab. Includes explanations, training, evaluation, inference, and the written summary. |
| `train.py` | Same pipeline as a plain Python script (for running from a terminal, e.g. on a lab machine or server). |
| `inference.py` | Loads the saved fine-tuned model and predicts sentiment for any sentence you pass on the command line. |
| `requirements.txt` | Python dependencies. |

---

## Important note on where to run this

This project downloads a pre-trained model (~270 MB) and the IMDb dataset
from the internet, and benefits a lot from a GPU. **Google Colab (free
tier) is the easiest way to run it** — it has both internet access and a
free GPU. Running it purely offline (e.g. in an environment with no
network access) will not work, since the model/dataset have to be
downloaded first.

---

## Step-by-step instructions

### Option A — Google Colab (recommended, easiest)

1. Go to https://colab.research.google.com and sign in with a Google account.
2. Click **File → Upload notebook**, and upload `Fine_Tuning_DistilBERT_Sentiment.ipynb`.
3. Click **Runtime → Change runtime type**, set **Hardware accelerator** to **GPU** (T4 is fine), and save.
4. Click **Runtime → Run all** (or run each cell one at a time with Shift+Enter).
5. The first code cell installs the required libraries — this takes 1–2 minutes.
6. Training (Section 6) takes roughly 5–10 minutes on a Colab T4 GPU with the
   default 2,000-example subset; several hours on CPU only for a small run,
   much longer for the full 25k dataset.
7. Once done, Section 9 will print predictions for a few example sentences.
   You can edit `sample_sentences` there to test your own text.
8. To keep the trained model, either download the `sentiment-distilbert-imdb/final_model`
   folder from Colab's file browser (left sidebar), or mount your Google Drive
   and copy it there before the Colab session ends (Colab storage is temporary).

### Option B — Your own machine (with a GPU, or patience on CPU)

1. **Install Python 3.9+** if you don't already have it.
2. **Create a virtual environment** (recommended):
   ```bash
   python -m venv venv
   source venv/bin/activate        # on Windows: venv\Scripts\activate
   ```
3. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```
4. **Run training:**
   ```bash
   python train.py
   ```
   This will download `distilbert-base-uncased` and the IMDb dataset
   automatically the first time it runs (needs internet access), fine-tune
   for 3 epochs on a 2,000-example subset (edit `TRAIN_SUBSET_SIZE` /
   `EVAL_SUBSET_SIZE` at the top of `train.py` to change this, or set them
   to `None` to use the full 25k/25k dataset), evaluate, save the model to
   `./sentiment-distilbert-imdb/final_model`, and print predictions for a
   few sample sentences.
5. **Run inference later on new text**, without retraining:
   ```bash
   python inference.py "This film was fantastic!" "I really did not enjoy this one."
   ```

### Adjusting for speed vs. accuracy

- `TRAIN_SUBSET_SIZE` / `EVAL_SUBSET_SIZE` — smaller = faster but slightly
  less accurate; set to `None` for the full dataset (best accuracy, slowest).
- `NUM_EPOCHS` — 3 is a good default; 2 is faster, 4–5 can slightly improve
  results but risks overfitting on a small subset.
- `BATCH_SIZE` — lower this (e.g. to 8) if you run out of GPU memory.

---

## Written Summary: Power and Limitations of Transfer Learning Here

**How transfer learning is applied:** DistilBERT is pre-trained on a huge,
general-purpose text corpus (a distilled version of BERT, itself trained on
BookCorpus + English Wikipedia). That pre-training gives the model broad
language understanding — grammar, word meaning, and context — before it
ever sees a movie review. Fine-tuning re-uses those learned weights and
only adapts them (with a small classification head added on top) to the
specific downstream task of sentiment classification. This is why strong
accuracy is reachable with a comparatively small labeled dataset and a
handful of training epochs — most of the "learning" already happened
during pre-training.

**Strengths:**
- Needs far less labeled data and compute than training a comparable
  model from scratch.
- DistilBERT retains most of BERT's language understanding while being
  smaller and faster, so it's practical to fine-tune on a single GPU.
- Captures contextual nuance (negation, mixed sentiment) better than
  classical bag-of-words approaches.

**Limitations:**
- May not generalize well to domains very different from movie reviews
  (e.g. product reviews, tweets).
- Fixed max input length (256 tokens here) truncates very long reviews.
- Binary positive/negative labels can't express neutral, mixed, or
  sarcastic sentiment.
- Inherits any biases present in the training data and in DistilBERT's
  original pre-training corpus.
- Training on the full 25k/25k dataset for several epochs still benefits
  significantly from a GPU; the default subset in this project trades
  some accuracy for a much faster demo run.

---

## Troubleshooting

- **`ImportError` for `transformers`/`datasets`/etc.** — re-run `pip install -r requirements.txt`.
- **Out of memory during training** — lower `BATCH_SIZE` in `train.py` (or the
  matching cell in the notebook), e.g. from 16 to 8.
- **Training is very slow** — you're likely on CPU. Use Google Colab with a
  GPU runtime (Option A above), or reduce `TRAIN_SUBSET_SIZE`.
- **No internet access** — this project needs to download the model and
  dataset on first run; it cannot run fully offline unless you've
  pre-downloaded and cached them.
- **`HfUriError: Invalid HF URI ... Repository id must be 'namespace/name'`
  when loading the IMDb dataset** — Hugging Face retired the old bare
  `"imdb"` dataset repo. This project already loads it from its new
  location, `"stanfordnlp/imdb"`. If you see this error, make sure you're
  using the latest version of the notebook/script from this project (or
  update any `load_dataset("imdb")` call yourself to
  `load_dataset("stanfordnlp/imdb")`), and upgrade the library with
  `pip install -U datasets huggingface_hub`.
