"""
Run sentiment inference using a fine-tuned DistilBERT model saved by
train.py (in ./sentiment-distilbert-imdb/final_model).

Usage:
    python inference.py "This film was fantastic!"
    python inference.py "This film was fantastic!" "I hated it."

If no sentence is given on the command line, a small demo set is used.
"""

import sys
import torch
from transformers import AutoTokenizer, AutoModelForSequenceClassification

MODEL_DIR = "./sentiment-distilbert-imdb/final_model"
ID2LABEL = {0: "NEGATIVE", 1: "POSITIVE"}


def load_model(model_dir: str = MODEL_DIR):
    tokenizer = AutoTokenizer.from_pretrained(model_dir)
    model = AutoModelForSequenceClassification.from_pretrained(model_dir)
    model.eval()
    return model, tokenizer


def predict(sentences, model, tokenizer):
    inputs = tokenizer(
        sentences, padding=True, truncation=True, max_length=256, return_tensors="pt"
    )
    with torch.no_grad():
        outputs = model(**inputs)
    probs = torch.nn.functional.softmax(outputs.logits, dim=-1)
    preds = torch.argmax(probs, dim=-1)

    results = []
    for sentence, pred, prob in zip(sentences, preds, probs):
        label = ID2LABEL[pred.item()]
        confidence = prob[pred].item()
        results.append((sentence, label, confidence))
    return results


def main():
    sentences = sys.argv[1:] or [
        "This movie was an absolute masterpiece, I loved every minute of it!",
        "What a waste of time. The plot made no sense and the acting was terrible.",
        "It was okay, not great, but not the worst thing I've watched either.",
    ]

    print(f"Loading fine-tuned model from '{MODEL_DIR}'...")
    model, tokenizer = load_model()

    results = predict(sentences, model, tokenizer)
    print("\nPredictions:")
    for sentence, label, confidence in results:
        print(f"  [{label}] ({confidence:.2%} confidence)  {sentence}")


if __name__ == "__main__":
    main()
